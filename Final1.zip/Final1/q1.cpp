#include <iostream>
#include <vector>
#include <string>
#include <set>
#include <algorithm>

using namespace std;

// N rows (H-rods), M columns (V-rods)
int N, M;
// Adjacency list for the bipartite graph
// Nodes 0 to N-1 are H-rods
// Nodes N to N+M-1 are V-rods
vector<vector<int>> adj;
vector<bool> visited;

// Stores all (r, c) intersections for the current component
set<pair<int, int>> component_cells;
vector<vector<char>> grid;

// DFS to find a connected component and all its cells
void dfs(int u) {
    visited[u] = true;

    // Find all cells related to this rod node
    if (u < N) {
        // This is an H-rod (node u is row u)
        for (int c = 0; c < M; ++c) {
            if (grid[u][c] != '.') {
                component_cells.insert({u, c});
                int v_node = N + c;
                if (!visited[v_node]) {
                    dfs(v_node);
                }
            }
        }
    } else {
        // This is a V-rod (node u is col u-N)
        int c = u - N;
        for (int r = 0; r < N; ++r) {
            if (grid[r][c] != '.') {
                component_cells.insert({r, c});
                int h_node = r;
                if (!visited[h_node]) {
                    dfs(h_node);
                }
            }
        }
    }
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);

    cin >> N >> M;

    grid.resize(N, vector<char>(M));
    adj.resize(N + M);
    visited.resize(N + M, false);

    bool has_intersections = false;

    for (int i = 0; i < N; ++i) {
        string row_str;
        cin >> row_str;
        for (int j = 0; j < M; ++j) {
            grid[i][j] = row_str[j];
            if (grid[i][j] != '.') {
                // Add edge: H-rod i <-> V-rod j
                int u = i;
                int v = N + j;
                adj[u].push_back(v);
                adj[v].push_back(u);
                has_intersections = true;
            }
        }
    }
    
    // Handle edge case of no intersections
    if (!has_intersections) {
        cout << 0 << endl;
        return 0;
    }

    int total_min_cost = 0;

    // Find all connected components
    for (int i = 0; i < N + M; ++i) {
        if (!visited[i] && !adj[i].empty()) {
            component_cells.clear();
            
            // Note: Our DFS logic will find all cells,
            // but we must start the DFS from a node that has edges.
            // The adj[i].empty() check handles isolated rods.
            // We'll start a modified DFS that explores from the grid
            // to handle the graph build and traversal in one.
            
            // Let's reset the visited array and use a simpler loop
            // The graph is already built, just traverse it
        }
    }
    
    // Reset visited for the actual traversal
    fill(visited.begin(), visited.end(), false);

    for (int i = 0; i < N; ++i) {
        for (int j = 0; j < M; ++j) {
            if (grid[i][j] != '.' && !visited[i]) {
                // Found an unvisited intersection
                // Start a DFS from its H-rod node
                component_cells.clear();
                dfs(i); // This will find the whole component

                int cost_R = 0;
                int cost_C = 0;

                for (const auto& cell : component_cells) {
                    if (grid[cell.first][cell.second] == 'C') {
                        cost_R++;
                    } else if (grid[cell.first][cell.second] == 'R') {
                        cost_C++;
                    }
                }
                total_min_cost += min(cost_R, cost_C);
            }
        }
    }

    cout << total_min_cost << endl;

    return 0;
}