from flask import Flask, render_template, request, jsonify
import numpy as np
import joblib

app = Flask(__name__)

# =================== LOAD MODELS ===================
model = joblib.load("model/lightgbm_model.pkl")         # Supervised model
behavior_map = joblib.load("model/behavior_map.pkl")    # Cluster → Behavior labels
print("✅ Model & behavior map loaded successfully!")

# =================== ROUTES ===================
@app.route("/")
def home():
    return render_template("index.html")

@app.route("/predict", methods=["POST"])
def predict():
    try:
        x = float(request.form.get("x"))
        y = float(request.form.get("y"))
        z = float(request.form.get("z"))
    except (TypeError, ValueError):
        return jsonify({"error": "Please enter numeric x, y, z values"}), 400

    # Compute total acceleration
    tot_accel = np.sqrt(x**2 + y**2 + z**2)
    features = np.array([[x, y, z, tot_accel]])

    # Predict cluster and map to behavior
    pred_cluster = model.predict(features)[0]
    behavior = behavior_map.get(pred_cluster, "Unknown")

    # Simple health rule
    if behavior == "Resting":
        status = "⚠️ Possible Sickness / Low Activity"
        color = "bad"
    elif behavior == "Grazing/Walking":
        status = "✅ Normal Behavior"
        color = "good"
    else:
        status = "💪 Very Active / Energetic"
        color = "normal"

    return jsonify({
        "behavior": behavior,
        "status": status,
        "color": color
    })

if __name__ == "__main__":
    app.run(debug=True)
